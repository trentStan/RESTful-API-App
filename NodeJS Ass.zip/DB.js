var db = require("@elastic/elasticsearch");
var fs = require("fs");
const indexNames = ["trentusers", "trenttasks"]
/*
const client = new db.Client({
  node: "https://07342ac3a1a84da099beed959e415a0c.us-central1.gcp.cloud.es.io",
  auth: {
    apiKey: "aFIwODlvZ0JpWUd2U3dGYW1hR046eklGVVZ4dXlSbmluSlhETERQdzZsZw==",
  },
});
*/

const client = new db.Client({
    node: "https://10.0.4.121:9200",
    auth: {
        username: "admin",
        password: "client_pass"
    },
    tls: {
        requestCert: true,
        ca: fs.readFileSync('intern121.crt'),
        rejectUnauthorized: false
    }
})

async function checkIndicesExists()
{

    client.indices.exists({ index: indexNames[0] })
        .then(async function (exists)
        {
            if (!exists)
            {
                await client.indices.create({
                    index: indexNames[0],
                    mappings: {
                        properties: {
                            'username': {
                                "type": 'text'
                            },
                            'first_name': {
                                'type': 'text'
                            },
                            'last_name': {
                                'type': 'text'
                            }
                        }
                    }
                }).then(function (r)
                {
                    console.log("Created: ", r.index)
                }).catch(function (err)
                {
                    console.log("something went wrong", err)
                })
            } else
            {
                console.log("index exists")
            }
        })

    await client.indices.exists({ index: indexNames[1] })
        .then(async function (exists)
        {
            if (!exists)
            {
                await client.indices.create({
                    index: indexNames[1],
                    mappings: {
                        properties: {
                            'name': {
                                "type": 'text'
                            },
                            'description_of_task': {
                                'type': 'text'
                            },
                            'date_time': {
                                'type': 'date',
                                'format': 'yyyy-MM-dd HH:mm:ss'
                            },
                            'status': {
                                'type': 'keyword'
                            },
                            'user_id': {
                                'type': 'text'

                            }
                        }
                    }
                }).then(function (r)
                {
                    console.log("Created: ", r.index)
                }).catch(function (err)
                {
                    console.log("something went wrong: ", err)
                })
            } else
            {
                console.log("index exists")
            }
        })

}

async function createUser(username, first_name, last_name)
{
    const respon = await client.index({
        index: indexNames[0],
        document: {
            username: username,
            first_name: first_name,
            last_name: last_name
        }
    }).then(function (result)
    {
        return { result: result.result, _id: result._id }
    }).catch(function (err)
    {
        console.log("Create user err: ",err)
        return err
    })

    return respon
}

function updateUser(id, first_name, last_name)
{
    const respon = client.update({
        index: indexNames[0],
        id: id,
        doc: {
            first_name: first_name,
            last_name: last_name
        }
    })
    return respon
}

function getAllUsers()
{
    const respon = client.search({
        index: indexNames[0],
        filter_path: ['hits.hits._id', 'hits.hits._source'],
        query: {
            match_all: {},
        }
    })
    return respon
}

function getUserInfo(id)
{
    const respon = client.get({
        index: indexNames[0],
        id: id,
        filter_path: ["_id", "_source"]
    })
    return respon
}

function addTasks(date_time, description, name, user_id, status = 'pending')
{
    const respon = client.index({
        index: indexNames[1],
        document: {
            date_time,
            description,
            name,
            status,
            user_id
        }
    })

    return respon
}

function updateTask(user_id, task_id, newName)
{
    const respon = client.update({
        index: indexNames[1],
        id: task_id,
        doc: {
            name: newName
        }
    })
    return respon
}

function deleteTask(user_id, task_id)
{
    const respon = client.delete({
        index: indexNames[1],
        id: task_id
    })
    return respon
}

function getTaskInfo(user_id, task_id)
{
    const respon = client.get({
        index: indexNames[1],
        id: task_id,
        filter_path: ["_id", "_source"]
    })

    return respon
}

function getTasksforUser(user_id)
{
    const respon = client.search({
        index: indexNames[1],
        query: {
            match: {
                "user_id": {
                    query: user_id
                }
            }
        },
        filter_path: ["hits.hits._id", "hits.hits._source"]
    })

    return respon
}

function getUnfinishedDueTasks()
{
    const respon = client.search({
        index: indexNames[1],
        query: {
            "bool": {
                "must": [
                    {
                        "term": {
                            "status": {
                                "value": "pending"
                            }
                        }
                    },
                    {
                        "range": {
                            "date_time": {
                                "lt": "now"
                            }
                        }
                    }
                ]
            }
        },
        filter_path: ["hits.hits._id", "hits.hits._source"]
    })

    return respon
}

function finishTasks()
{
    const respon = client.updateByQuery({
        index: indexNames[1],
        query: {
            "bool": {
                "must": [
                  {
                    "term": {
                      "status": {
                        "value": "pending"
                      }
                    }
                  },
                  {
                    "range": {
                      "date_time": {
                        "lt": "now"
                      }
                    }
                  }
                ]
              }
        },
        script: {
            "source": "ctx._source.status='done'",
            "lang": "painless"
        }
    })

    return respon
}

const elasticTools = { checkIndicesExists, createUser, getAllUsers, updateUser, getUserInfo, addTasks, updateTask, deleteTask, getTaskInfo, getTasksforUser, finishTasks, getUnfinishedDueTasks }

module.exports = elasticTools;