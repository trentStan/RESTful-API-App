var express = require('express');
var router = express.Router();
var elasticTools = require('../DB')
var cron = require('node-cron')
// base route: /api/users

async function showAndfinishTasks(now)
{
    await elasticTools.getUnfinishedDueTasks().then(function (result)
    {
        try
        {
            console.log(result.hits.hits)
        } catch (error)
        {
            console.log("\nno tasks to finish")
        }

    })

    await elasticTools.finishTasks().then(function (result)
    {

        console.log("Tasks Completed: ", now.toString())
        console.log("Total: " + result.total + "\n"
            + "Updated: " + result.updated)
    })
}

// Create User
router.post("/", function (req, res, next)
{

    elasticTools.createUser(req.body.username, req.body.first_name, req.body.last_name)
        .then(function (result)
        {
            res.send(result)
        })
        .catch(function (err)
        {
            res.send("Something went wrong: ", err)
        })

})

// Update user
router.put("/:id", function (req, res)
{
    elasticTools.updateUser(req.params.id, req.body.first_name, req.body.last_name)
        .then(function (result)
        {
            res.send({ id: result._id, result: result.result })
        }).catch(function (err)
        {
            res.send("Something went wrong: ", err)
        })
})

// List all users
router.get('/', function (req, res)
{
    elasticTools.getAllUsers()
        .then(function (result)
        {
            var usrs = result.hits.hits
            res.send(usrs)
        })
        .catch(function (err)
        {
            res.send("something went wrong: ", err)
        })

})

// Get User info
router.get('/:id', function (req, res)
{
    elasticTools.getUserInfo(req.params.id)
        .then(function (result)
        {
            res.send(result)
        })
        .catch(function (err)
        {
            res.send("Something went wrong: ", err)
        })
})

// Create task
router.post('/:user_id/tasks', function (req, res)
{
    elasticTools.addTasks(req.body.date_time, req.body.description, req.body.name, req.params.user_id)
        .then(function (result)
        {
            res.send({ task_id: result._id, result: result.result })
        })
        .catch(function (err)
        {
            res.send("Something went wrong", err)
        })
})

// Update Task
router.put('/:user_id/tasks/:task_id', function (req, res)
{
    elasticTools.updateTask(req.params.user_id, req.params.task_id, req.body.name)
        .then(function (result)
        {
            res.send({ id: result._id, result: result.result })
        })
        .catch(function (err)
        {
            res.send("Something went wrong: ", err)
        })
})

// Delete Task
router.delete('/:user_id/tasks/:task_id', function (req, res)
{
    elasticTools.deleteTask(req.params.user_id, req.params.task_id)
        .then(function (result)
        {
            res.send({ id: result._id, result: result.result })
        })
        .catch(function (err)
        {
            res.send("Something went wrong", err)
        })
})

// Get Task Info
router.get('/:user_id/tasks/:task_id', function (req, res)
{
    elasticTools.getTaskInfo(req.params.user_id, req.params.task_id)
        .then(function (result)
        {
            res.send(result)
        })
        .catch(function (err)
        {
            res.send("something went wrong: ", err)
        })
})

// List all tasks for a user
router.get('/:user_id/tasks', function (req, res)
{
    elasticTools.getTasksforUser(req.params.user_id)
        .then(function (result)
        {
            res.send(result.hits.hits)
        })
        .catch(function (err)
        {
            res.send(err)
        })
})

elasticTools.checkIndicesExists().then(function ()
{
    console.log("db all good")
    cron.schedule('59 * * * * *', function (now)
    {
        showAndfinishTasks(now)
            .catch(function (err)
            {
                console.log(err)
            })
    })
})
    .catch(function (err)
    {
        console.log("Database error: ", err)
    })
module.exports = router;